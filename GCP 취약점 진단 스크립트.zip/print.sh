function print(){
  echo "----------------------------------"$title1" 검사----------------------------------"
  echo "서비스 : "$title1
  echo "항목번호 : "$title2
  echo "진단항목 : "$title3
  echo "점검결과 : "$check
  echo "리소스 : "$resource
  echo "비고 : "$text
}

print


